#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class GestureNode(Node):
    def __init__(self):
        super().__init__('gesture_node')
        self.publisher_ = self.create_publisher(String, '/gesture_cmd', 10)
        self.timer = self.create_timer(2.0, self.detect_and_publish_gesture)
        self.gestures = ['wave_left', 'wave_right', 'thumbs_up', 'fist', 'open_hand']

    def detect_and_publish_gesture(self):
        gesture = random.choice(self.gestures)
        msg = String()
        msg.data = gesture
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published gesture: {gesture}')

def main(args=None):
    rclpy.init(args=args)
    node = GestureNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
