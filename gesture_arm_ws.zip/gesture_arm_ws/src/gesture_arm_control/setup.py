from setuptools import setup
import os
from glob import glob

package_name = 'gesture_arm_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
    ('share/ament_index/resource_index/packages',
     ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    (os.path.join('share', package_name, 'launch'), glob('gesture_arm_control/launch/*.py')),
    (os.path.join('share', package_name, 'urdf'), glob('gesture_arm_control/robot_description/urdf/*.xacro')),
    (os.path.join('share', package_name, 'config'), glob('gesture_arm_control/robot_description/config/*.yaml')),
    (os.path.join('share', package_name, 'rviz'), glob('gesture_arm_control/rviz/*.rviz')),
],

    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='suwi',
    maintainer_email='suwi@example.com',
    description='Gesture-controlled 2DOF robotic arm with RViz and Gazebo',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'gesture_detection = gesture_arm_control.gesture_detection:main',
            'gesture_to_joint_controller = gesture_arm_control.gesture_to_joint_controller:main',
        ],
    },
)
