# Gesture Arm Control 🤖🖐️

This package allows you to control a simulated 2DOF robotic arm using hand gestures via webcam, visualized in Gazebo and RViz2.

## Features
- Hand tracking with MediaPipe
- Joint control based on gesture detection
- Simulation in Gazebo
- Visual feedback in RViz2

## How to Run

```bash
cd ~/gesture_arm_ws
colcon build
source install/setup.bash
ros2 launch gesture_arm_control full_system.launch.py

