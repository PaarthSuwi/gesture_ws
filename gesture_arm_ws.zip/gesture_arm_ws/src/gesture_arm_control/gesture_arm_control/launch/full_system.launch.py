from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

import os

def generate_launch_description():
    pkg_gesture = FindPackageShare("gesture_arm_control")
    controller_yaml = PathJoinSubstitution([pkg_gesture, "config", "controller.yaml"])
    urdf_file = PathJoinSubstitution([pkg_gesture, "urdf", "2dof_arm.urdf.xacro"])

    # Load robot state
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{
            "robot_description": Command(["xacro ", urdf_file])
        }]
    )

    # Joint state publisher (for RViz sliders if needed)
    joint_state_pub_gui = Node(
        package="joint_state_publisher_gui",
        executable="joint_state_publisher_gui",
        name="joint_state_publisher_gui",
        output="screen"
    )

    # Launch Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare("gazebo_ros"), "/launch/gazebo.launch.py"]
        )
    )

    # Spawn robot into Gazebo
    spawn_entity = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=["-topic", "robot_description", "-entity", "gesture_arm"],
        output="screen"
    )

    # Start controller manager
    controller_manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[{
            "robot_description": Command(["xacro ", urdf_file])
        }, controller_yaml],
        output="screen"
    )

    # Load joint state broadcaster and position controllers
    load_joint_state_broadcaster = ExecuteProcess(
        cmd=["ros2", "control", "load_controller", "--set-state", "active", "joint_state_broadcaster"],
        output="screen"
    )

    load_joint1_controller = ExecuteProcess(
        cmd=["ros2", "control", "load_controller", "--set-state", "active", "joint1_position_controller"],
        output="screen"
    )

    load_joint2_controller = ExecuteProcess(
        cmd=["ros2", "control", "load_controller", "--set-state", "active", "joint2_position_controller"],
        output="screen"
    )

    # RViz2
    rviz2 = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen"
    )

    # Gesture detection node
    gesture_detection_node = Node(
        package="gesture_arm_control",
        executable="gesture_detection",
        name="gesture_detection",
        output="screen"
    )

    # Gesture to joint controller node
    joint_control_node = Node(
        package="gesture_arm_control",
        executable="gesture_to_joint_controller",
        name="gesture_controller",
        output="screen"
    )

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        joint_state_pub_gui,
        controller_manager,
        TimerAction(period=4.0, actions=[  # wait for Gazebo + controller manager
            load_joint_state_broadcaster,
            load_joint1_controller,
            load_joint2_controller
        ]),
        rviz2,
        gesture_detection_node,
        joint_control_node
    ])
