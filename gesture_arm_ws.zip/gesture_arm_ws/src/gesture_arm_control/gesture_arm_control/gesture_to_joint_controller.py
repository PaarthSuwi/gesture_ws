import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float64


class GestureToJointController(Node):
    def __init__(self):
        super().__init__('gesture_to_joint_controller')

        self.subscription = self.create_subscription(
            String,
            'gesture_recog',
            self.gesture_callback,
            10)

        self.joint1_pub = self.create_publisher(Float64, '/joint1_position_controller/command', 10)
        self.joint2_pub = self.create_publisher(Float64, '/joint2_position_controller/command', 10)

        self.joint1_angle = 0.0
        self.joint2_angle = 0.0
        self.step = 0.1  # change per gesture

        self.get_logger().info("Gesture → Joint Controller Node Started")

    def gesture_callback(self, msg):
        gesture = msg.data.lower()
        if gesture == "left":
            self.joint1_angle += self.step
        elif gesture == "right":
            self.joint1_angle -= self.step
        elif gesture == "up":
            self.joint2_angle += self.step
        elif gesture == "down":
            self.joint2_angle -= self.step
        elif gesture == "stop":
            pass  # do nothing

        self.joint1_angle = max(-3.14, min(3.14, self.joint1_angle))
        self.joint2_angle = max(-1.57, min(1.57, self.joint2_angle))

        self.joint1_pub.publish(Float64(data=self.joint1_angle))
        self.joint2_pub.publish(Float64(data=self.joint2_angle))

        self.get_logger().info(f"Sent joint1: {self.joint1_angle:.2f}, joint2: {self.joint2_angle:.2f}")


def main(args=None):
    rclpy.init(args=args)
    node = GestureToJointController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
