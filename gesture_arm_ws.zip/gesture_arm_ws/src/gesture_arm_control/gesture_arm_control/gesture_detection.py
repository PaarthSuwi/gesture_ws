import cv2
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import mediapipe as mp


class GestureDetectionNode(Node):
    def __init__(self):
        super().__init__('gesture_detection')

        self.publisher_ = self.create_publisher(String, 'gesture_recog', 10)
        self.timer = self.create_timer(0.1, self.detect_gesture)

        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(max_num_hands=1)
        self.cap = cv2.VideoCapture(0)

        self.get_logger().info("Gesture Detection Node Started!")

    def detect_gesture(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        # Flip image for selfie view
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = self.hands.process(rgb)

        gesture = None

        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                wrist = hand_landmarks.landmark[self.mp_hands.HandLandmark.WRIST]
                index_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.INDEX_FINGER_TIP]
                middle_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_TIP]

                # Basic gesture rule: if index is above middle → up
                if index_tip.y < middle_tip.y and abs(index_tip.x - middle_tip.x) < 0.05:
                    gesture = "up"
                elif index_tip.y > middle_tip.y and abs(index_tip.x - middle_tip.x) < 0.05:
                    gesture = "down"
                elif index_tip.x < wrist.x:
                    gesture = "left"
                elif index_tip.x > wrist.x:
                    gesture = "right"

        if gesture:
            msg = String()
            msg.data = gesture
            self.publisher_.publish(msg)
            self.get_logger().info(f"Gesture: {gesture}")

        # Display (optional)
        cv2.imshow("Gesture View", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.cap.release()
            cv2.destroyAllWindows()
            rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = GestureDetectionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

